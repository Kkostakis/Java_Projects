public class Menu 
{

	private String code;
	private String maindishes;
	private String desserts;
    private String drinks;
    
    public Menu(String code,String maindishes,String desserts,String drinks)
    {
    	setCODE(code);
    	setMAINDISHES(maindishes);
    	setDESSERTS(desserts);
    	setDRINKS(drinks);
    	
    }
    
    public void setCODE(String code)
    {
    	this.code = code;
    }
    
    public String getCODE()
    {
    	return this.code;
    }

	public void setMAINDISHES(String maindishes) 
	{
		this.maindishes = maindishes;
	}
	
	public String getMAINDISHES() 
	{
		return this.maindishes;
	}

	public void setDESSERTS(String desserts) 
	{
		this.desserts = desserts;
	}
	
	public String getDESSERTS() {
		return this.desserts;
	}

	public void setDRINKS(String drinks) 
	{
		this.drinks = drinks;
	}
    
	public String getDRINKS() 
	{
		return this.drinks;
	}

}
