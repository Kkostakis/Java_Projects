public class EconomySeat extends Seat
{

	public EconomySeat(String code, int numr, int numc, String ticket)
	{
		super(code, numr, numc, ticket);
	}

	
}
