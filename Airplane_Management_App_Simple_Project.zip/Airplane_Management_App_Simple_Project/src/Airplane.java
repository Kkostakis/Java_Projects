public class Airplane
{

	private String code;
	private int rows;
	private int columns;
	private int businessrows; 
	private String description;


	public Airplane(String code,int rows,int columns,String description,int businessrows)
	{
		this.setBUSINESS(businessrows);
		this.setCODE(code);
		this.setROWS(rows);
		this.setCOLUMNS(columns);
		this.setDESCRIPTION(description);
	}
	
	
	public void setCODE(String code)
	{
		this.code = code;
	}
	
	public String getCODE()
	{  
		return this.code;
	}
	
	public void setROWS(int rows)
	{
		this.rows =  rows;
	}
	
	public int getROWS()
	{
		return this.rows;
	}
	
	public void setCOLUMNS(int columns)
	{
		this.columns = columns;
	}
	
	public int getCOLUMNS()
	{
		return this.columns;
	}
	
	public void setDESCRIPTION(String description)
	{
		this.description = description;
	}
	
	public String getDESCRIPTION()
	{
		return this.description;
	}	
	
	public void setBUSINESS(int businessrows)
	{
		this.businessrows = businessrows;
	}
	
	public int getBUSINESS()
	{
		return this.businessrows;
	}
}
